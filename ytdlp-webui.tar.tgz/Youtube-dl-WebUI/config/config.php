<?php

//Default password is "root" with md5 hash
//No "/" at the end of outputFolder or logfolder

return array(
	"bin" => "/usr/bin/yt-dlp",
	"security" => true,
	"password" => "6f500431a7ba2b3be79d68cd89496b7d",
	"outputFolder" => "downloads",
	"extracter" => "ffmpeg",
	"log" => true,
	"outfilename" => "%(title)s-%(id)s.%(ext)s",
	"logFolder" => "/mnt/data/ytdlp-logs",
	"max_dl" => 3,
	"session_lifetime" => 86400);

?>
